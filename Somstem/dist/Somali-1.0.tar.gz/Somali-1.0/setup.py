from setuptools import setup, find_packages

setup(
    name='Somali',
    version='1.0',
    author='Abdisalam M.',
    author_email='fiicane121@gmail.com',
    description='This is a rule based stemmer for somali language.',
    packages=find_packages(),
    install_requires=[
    ],
)
